//
//  CatCell.swift
//  catCrawerer
//
//  Created by 김윤서의 핵 개발소 on 2023/03/02.
//

import Foundation
import UIKit

final class CatCell: UICollectionViewCell{
    private let imageView = UIImageView()
    
    private let service = ImageService.shared
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setupView()
        
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupView() {
        self.addSubview(self.imageView)
        self.imageView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            self.imageView.topAnchor.constraint(equalTo: self.topAnchor),
            self.imageView.leadingAnchor.constraint(equalTo: self.leadingAnchor),
            self.imageView.trailingAnchor.constraint(equalTo: self.trailingAnchor),
            self.imageView.bottomAnchor.constraint(equalTo: self.bottomAnchor)
        ])
        self.imageView.backgroundColor = .cyan
        self.imageView.clipsToBounds = true
        self.imageView.contentMode = .scaleAspectFill
    }
    func setupData(urlString: String){
        service.setImage(view: self.imageView, urlString: urlString)
    }
}

