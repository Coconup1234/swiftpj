//
//  ViewController.swift
//  catCrawerer
//
//  Created by 김윤서의 핵 개발소 on 2023/02/19.
//

import UIKit

class ViewController: UIViewController, CatViewModelOutput {
    
    private enum Metrics{
        static let inset: CGFloat = 4
    }

    private let collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        let cv = UICollectionView(frame: .zero,collectionViewLayout:layout)
        cv.backgroundColor = .white
        layout.minimumLineSpacing = Metrics.inset
        layout.minimumInteritemSpacing = Metrics.inset
        return cv
        
    }()
    
    private let viewModel = CatViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupView()
        // Do any additional setup after loading the view.
    }

    private func setupView() {
        self.view.addSubview(self.collectionView)
        
        self.collectionView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            self.collectionView.topAnchor.constraint(equalTo: self.view.topAnchor),
            self.collectionView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor),
            self.collectionView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor),
            self.collectionView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        ])
        self.collectionView.backgroundColor = .systemPink
        self.collectionView.register(CatCell.self, forCellWithReuseIdentifier: "cell")
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        self.collectionView.reloadData()
        self.viewModel.delegate = self
        self.viewModel.load()
        
        
    }
    func loadComplate() {
        DispatchQueue.main.async {
            self.collectionView.reloadData()
        }
        
    }
    
}

extension ViewController: UICollectionViewDelegateFlowLayout{
    internal func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout,sizeForItemAt indexPath: IndexPath) ->CGSize {
        
        let width = collectionView.frame.width
        
        let cellwidth = (width - 2 * Metrics.inset) / 3
        return CGSize(width: cellwidth, height: cellwidth)
        
    }
        
    
}

extension ViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.viewModel.data.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CatCell
        let data = self.viewModel.data[indexPath.item]
        cell.setupData(urlString: data.url)
        cell.backgroundColor = .black
        return cell
    }
    
    
}
