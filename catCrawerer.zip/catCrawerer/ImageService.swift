//
//  ImageService.swift
//  catCrawerer
//
//  Created by 김윤서의 핵 개발소 on 2023/03/10.
//

import Foundation
import UIKit


class ImageService{
    static let shared = ImageService()
    
    enum Network: Error {
        case networkError
    }
    
    func downloadImage(url: String, complection: @escaping(Result<UIImage, Network>)->Void{
        
        var request = URLRequest(url: URL(string: urlString)!)
        request.httpMethod = "GET"
        let Task = URLSession.shared.dataTask(with: request) {
            data, request, error in
            
            guard error == nil{
                completion(.failure(.networkError))
                return
            }
            
            guard let data = data else{
                completion(.failure(.networkError))
                return
            }
            guard let image = UIImage(data: data)else{
                completion(.failure(.networkError))
            }
        }
    }
}
