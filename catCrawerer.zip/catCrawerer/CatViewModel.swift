//
//  CatViewModel.swift
//  catCrawerer
//
//  Created by 김윤서의 핵 개발소 on 2023/03/06.
//

import Foundation

protocol CatViewModelOutput: AnyObject{
    func loadComplate()
}

final class CatViewModel{
    private var currentPage = 0
    
    private var limit = 3*7
    
    
    
    
    private let service = CatService()
    
    var data: [CatResponse] = []
    weak var delegate: CatViewModelOutput?
    func load() {
        self.service.getCats(page: self.currentPage, limit: self.limit){
            
            result in
            
            switch result{
            case .failure(let error):
                break
            case.success(let response):
                self.data.append(contentsOf: response)
                self.delegate?.loadComplate()
            }
        }
    }
}
